document.getElementById('signup-form').addEventListener('submit', async function (e) {
    e.preventDefault();

    const formData = new FormData(this);
    const data = {
        nama_lengkap: formData.get('signup-nama-lengkap'),
        username: formData.get('signup-username'),
        email: formData.get('signup-email'),
        password: formData.get('signup-password')
    };

    const response = await fetch('/signup', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
    });

    const messageElement = document.getElementById('signupMessage');
    if (response.ok) {
        messageElement.innerText = "User created successfully";
        messageElement.classList.remove('text-red-500');
        messageElement.classList.add('text-green-500');
    } else {
        const errorMessage = await response.text();
        messageElement.innerText = errorMessage;
        messageElement.classList.remove('text-green-500');
        messageElement.classList.add('text-red-500');
    }
});
