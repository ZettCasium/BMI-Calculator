document.addEventListener('DOMContentLoaded', function() {
    const signinSignupButton = document.getElementById('signin-signup-btn');
    const modal = document.getElementById('auth-modal');
    const closeModal = document.getElementById('close-modal');

    if (signinSignupButton && modal && closeModal) {
        signinSignupButton.addEventListener('click', function(event) {
            event.preventDefault();  // Prevent default action
            modal.classList.remove('hidden');
        });

        closeModal.addEventListener('click', function() {
            modal.classList.add('hidden');
        });

        window.addEventListener('click', function(event) {
            if (event.target == modal) {
                modal.classList.add('hidden');
            }
        });
    }
});
