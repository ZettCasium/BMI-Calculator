async function fetchUserData() {
    try {
        const response = await fetch('/get-user-data');
        const userData = await response.json();
        console.log('User Data:', userData);

        document.getElementById('full-name').textContent = userData.nama_lengkap;
        document.getElementById('bmi').textContent = userData.bmi.toFixed(2);
        document.getElementById('category').textContent = userData.category;
        document.getElementById('daily-calorie-needs').textContent = userData.daily_calorie_needs.toFixed(2);

        // Fetch progress data
        const progressResponse = await fetch('/get-progress-data');
        const progressData = await progressResponse.json();
        console.log('Progress Data:', progressData);

        const progressTableBody = document.getElementById('progressTableBody');
        progressTableBody.innerHTML = ''; // Clear previous data

        progressData.forEach(progress => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${progress.date}</td>
                <td>${progress.weight}</td>
                <td>${progress.bmi}</td>
            `;
            progressTableBody.appendChild(row);
        });
    } catch (error) {
        console.error('Error fetching user data:', error);
    }
}

fetchUserData();
