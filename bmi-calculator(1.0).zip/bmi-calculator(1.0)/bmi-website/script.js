document.addEventListener('DOMContentLoaded', function () {
    const bmiForm = document.querySelector('form');
    const resultDiv = document.getElementById('result');

    bmiForm.addEventListener('submit', async function (e) {
        e.preventDefault();

        const age = parseInt(document.getElementById('age').value);
        const weight = parseFloat(document.getElementById('weight').value);
        const height = parseFloat(document.getElementById('height').value);
        const activityLevel = parseFloat(document.querySelector('input[name="activityLevel"]:checked')?.value);

        if (!activityLevel) {
            alert('Please select an activity level.');
            return;
        }

        try {
            const response = await fetch('/submit-bmi', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ age, weight, height, activityLevel })
            });

            if (response.ok) {
                const result = await response.json();
                const bmiText = result.bmi ? `BMI: ${result.bmi.toFixed(2)}` : 'BMI: Error';
                const categoryText = result.category ? `Category: ${result.category}` : 'Category: Error';
                const caloriesText = result.caloricNeeds ? `Daily Caloric Needs: ${result.caloricNeeds.toFixed(2)} kcal` : 'Daily Caloric Needs: Error';

                resultDiv.innerText = `${bmiText}, ${categoryText}, ${caloriesText}`;
            } else {
                resultDiv.innerText = 'Error calculating BMI';
            }
        } catch (error) {
            console.error('Error:', error);
            resultDiv.innerText = 'Error calculating BMI';
        }
    });
});
