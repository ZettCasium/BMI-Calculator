package main

import (
	"database/sql"
	"encoding/json"
	"fmt"
	"log"
	"math"
	"net/http"
	"path/filepath"
	"strconv"

	_ "github.com/go-sql-driver/mysql"
	"github.com/gorilla/sessions"
	"golang.org/x/crypto/bcrypt"
)

var (
	db    *sql.DB
	store = sessions.NewCookieStore([]byte("super-secret-key")) // Replace with your secret key
)

type Credentials struct {
	ID          int    `json:"id"`
	NamaLengkap string `json:"nama_lengkap"`
	Username    string `json:"username"`
	Email       string `json:"email"`
	Password    string `json:"password"`
}

// Progress struct definition
type Progress struct {
	Date   string  `json:"date"`
	Weight float64 `json:"weight"`
	BMI    float64 `json:"bmi"`
}

type UserData struct {
	Nama              string  `json:"nama"`
	BMI               float64 `json:"bmi"`
	Category          string  `json:"category"`
	DailyCalorieNeeds float64 `json:"daily_calorie_needs"`
}

type BMICalculation struct {
	Age               int     `json:"age"`
	Weight            float64 `json:"weight"`
	Height            float64 `json:"height"`
	ActivityLevel     float64 `json:"activityLevel"`
	BMI               float64 `json:"bmi"`
	Category          string  `json:"category"`
	DailyCalorieNeeds float64 `json:"caloricNeeds"`
}

func main() {
	var err error
	db, err = sql.Open("mysql", "root@tcp(127.0.0.1:3306)/bmicalculator")
	if err != nil {
		log.Fatal(err)
	}
	defer db.Close()

	if err = db.Ping(); err != nil {
		log.Fatal(err)
	}

	// Serve HTML files
	http.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path == "/" {
			http.ServeFile(w, r, "index.html")
			return
		}
		http.ServeFile(w, r, r.URL.Path[1:])
	})

	// Serve JavaScript files with correct MIME type
	http.HandleFunc("/js/", func(w http.ResponseWriter, r *http.Request) {
		jsFilePath := filepath.Join(".", r.URL.Path)
		w.Header().Set("Content-Type", "application/javascript")
		http.ServeFile(w, r, jsFilePath)
	})

	/*fs := http.FileServer(http.Dir("./"))
	http.Handle("/", fs)*/
	http.HandleFunc("/signup", SignupHandler)
	http.HandleFunc("/login", LoginHandler)
	http.HandleFunc("/logout", LogoutHandler)
	http.HandleFunc("/account", AccountHandler)
	http.HandleFunc("/check-login", CheckLoginStatusHandler)
	http.Handle("/submit-progress", authMiddleware(http.HandlerFunc(SubmitProgressHandler)))
	http.HandleFunc("/get-progress", GetProgressHandler)
	http.Handle("/submit-bmi", authMiddleware(http.HandlerFunc(SubmitBMIHandler)))

	// Example handlers for user data and progress data
	http.HandleFunc("/get-user-data", GetUserDataHandler)
	http.HandleFunc("/get-progress-data", GetProgressDataHandler)
	log.Fatal(http.ListenAndServe(":3000", nil))
}

// Add this helper function to parse float values
func parseFloat(value string) (float64, error) {
	return strconv.ParseFloat(value, 64)
}

func calculateBMI(weight, height float64) float64 {
	return weight / math.Pow(height/100, 2)
}

func determineBMICategory(bmi float64) string {
	switch {
	case bmi < 18.5:
		return "Underweight"
	case bmi >= 18.5 && bmi < 24.9:
		return "Normal weight"
	case bmi >= 24.9 && bmi < 29.9:
		return "Overweight"
	default:
		return "Obesity"
	}
}

func calculateDailyCaloricNeeds(weight, height float64, age int, activityLevel float64) float64 {
	bmr := 10*weight + 6.25*height - 5*float64(age) + 5 // Basic Metabolic Rate for males
	return bmr * activityLevel
}

func SubmitBMIHandler(w http.ResponseWriter, r *http.Request) {
	userID, err := getUserID(r)
	if err != nil {
		http.Error(w, "Unauthorized: "+err.Error(), http.StatusUnauthorized)
		return
	}

	var bmiData BMICalculation
	err = json.NewDecoder(r.Body).Decode(&bmiData)
	if err != nil {
		http.Error(w, "Invalid request payload", http.StatusBadRequest)
		return
	}

	bmiData.BMI = calculateBMI(bmiData.Weight, bmiData.Height)
	bmiData.Category = determineBMICategory(bmiData.BMI)
	bmiData.DailyCalorieNeeds = calculateDailyCaloricNeeds(bmiData.Weight, bmiData.Height, bmiData.Age, bmiData.ActivityLevel)

	_, err = db.Exec("UPDATE users SET bmi = ?, category = ?, daily_calorie_needs = ? WHERE id = ?",
		bmiData.BMI, bmiData.Category, bmiData.DailyCalorieNeeds, userID)
	if err != nil {
		log.Printf("Error updating BMI data: %v", err)
		http.Error(w, "Error updating BMI data: "+err.Error(), http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(bmiData)
}

func SignupHandler(w http.ResponseWriter, r *http.Request) {
	var creds Credentials
	err := json.NewDecoder(r.Body).Decode(&creds)
	if err != nil {
		http.Error(w, "Invalid request payload", http.StatusBadRequest)
		return
	}

	hashedPassword, err := bcrypt.GenerateFromPassword([]byte(creds.Password), bcrypt.DefaultCost)
	if err != nil {
		http.Error(w, "Error hashing password", http.StatusInternalServerError)
		return
	}

	_, err = db.Exec("INSERT INTO users (nama_lengkap, username, email, password) VALUES (?, ?, ?, ?)",
		creds.NamaLengkap, creds.Username, creds.Email, string(hashedPassword))
	if err != nil {
		http.Error(w, "Error creating user", http.StatusInternalServerError)
		return
	}

	// Fetch the inserted user's ID
	var userID int
	err = db.QueryRow("SELECT id FROM users WHERE email = ?", creds.Email).Scan(&userID)
	if err != nil {
		http.Error(w, "Error fetching user ID", http.StatusInternalServerError)
		return
	}

	// Initialize BMI data (this can be updated later)
	_, err = db.Exec("UPDATE users SET bmi = ?, category = ?, daily_calorie_needs = ? WHERE id = ?",
		0.0, "", 0.0, userID)
	if err != nil {
		http.Error(w, "Error initializing BMI data", http.StatusInternalServerError)
		return
	}

	w.WriteHeader(http.StatusCreated)
}

func LoginHandler(w http.ResponseWriter, r *http.Request) {
	var creds Credentials
	err := json.NewDecoder(r.Body).Decode(&creds)
	if err != nil {
		log.Printf("Invalid request: %v", err)
		http.Error(w, "Invalid request: "+err.Error(), http.StatusBadRequest)
		return
	}

	var storedCreds Credentials
	query := `SELECT id, nama_lengkap, username, email, password FROM users WHERE email = ?`
	err = db.QueryRow(query, creds.Email).Scan(&storedCreds.ID, &storedCreds.NamaLengkap, &storedCreds.Username, &storedCreds.Email, &storedCreds.Password)
	if err != nil {
		log.Printf("User not found: %v", err)
		http.Error(w, "Invalid credentials", http.StatusUnauthorized)
		return
	}

	err = bcrypt.CompareHashAndPassword([]byte(storedCreds.Password), []byte(creds.Password))
	if err != nil {
		log.Printf("Password mismatch: %v", err)
		http.Error(w, "Invalid credentials", http.StatusUnauthorized)
		return
	}

	session, _ := store.Get(r, "session")
	session.Values["user_id"] = storedCreds.ID
	session.Save(r, w)

	w.Write([]byte("Login successful"))
}

func LogoutHandler(w http.ResponseWriter, r *http.Request) {
	session, _ := store.Get(r, "session")
	delete(session.Values, "user_id")
	session.Save(r, w)
	w.Write([]byte("Logout successful"))
}

func AccountHandler(w http.ResponseWriter, r *http.Request) {
	session, _ := store.Get(r, "session")
	userID, ok := session.Values["user_id"].(int)
	if !ok || userID == 0 {
		http.Error(w, "Not logged in", http.StatusUnauthorized)
		return
	}

	var user Credentials
	query := `SELECT nama_lengkap, username, email FROM users WHERE id = ?`
	err := db.QueryRow(query, userID).Scan(&user.NamaLengkap, &user.Username, &user.Email)
	if err != nil {
		http.Error(w, "User not found", http.StatusNotFound)
		return
	}

	json.NewEncoder(w).Encode(user)
}

func CheckLoginStatusHandler(w http.ResponseWriter, r *http.Request) {
	session, _ := store.Get(r, "session")
	userID, ok := session.Values["user_id"].(int)
	if !ok || userID == 0 {
		w.WriteHeader(http.StatusUnauthorized)
		w.Write([]byte("Not logged in"))
		return
	}

	var username string
	query := `SELECT username FROM users WHERE id = ?`
	err := db.QueryRow(query, userID).Scan(&username)
	if err != nil {
		http.Error(w, "User not found", http.StatusInternalServerError)
		return
	}

	response := map[string]string{"username": username}
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(response)
}

// Submit progress handler
func SubmitProgressHandler(w http.ResponseWriter, r *http.Request) {
	userID, err := getUserID(r)
	if err != nil {
		http.Error(w, "Unauthorized: "+err.Error(), http.StatusUnauthorized)
		return
	}

	var progressData map[string]string
	err = json.NewDecoder(r.Body).Decode(&progressData)
	if err != nil {
		log.Printf("Invalid request: %v", err)
		http.Error(w, "Invalid request: "+err.Error(), http.StatusBadRequest)
		return
	}

	weight, err := parseFloat(progressData["weight"])
	if err != nil {
		log.Printf("Invalid weight value: %v", err)
		http.Error(w, "Invalid weight value: "+err.Error(), http.StatusBadRequest)
		return
	}

	bmi, err := parseFloat(progressData["bmi"])
	if err != nil {
		log.Printf("Invalid BMI value: %v", err)
		http.Error(w, "Invalid BMI value: "+err.Error(), http.StatusBadRequest)
		return
	}

	progress := Progress{
		Date:   progressData["date"],
		Weight: weight,
		BMI:    bmi,
	}

	query := `INSERT INTO progress (user_id, date, weight, bmi) VALUES (?, ?, ?, ?)`
	_, err = db.Exec(query, userID, progress.Date, progress.Weight, progress.BMI)
	if err != nil {
		log.Printf("Error inserting progress data: %v", err)
		http.Error(w, "Error submitting progress data: "+err.Error(), http.StatusInternalServerError)
		return
	}

	w.WriteHeader(http.StatusCreated)
	w.Write([]byte("Progress data submitted successfully"))
}

// Get progress handler
func GetProgressHandler(w http.ResponseWriter, r *http.Request) {
	userID, err := getUserID(r)
	if err != nil {
		http.Error(w, "Unauthorized: "+err.Error(), http.StatusUnauthorized)
		return
	}

	query := `SELECT date, weight, bmi FROM progress WHERE user_id = ? ORDER BY date`
	rows, err := db.Query(query, userID)
	if err != nil {
		http.Error(w, "Error fetching progress data: "+err.Error(), http.StatusInternalServerError)
		return
	}
	defer rows.Close()

	var progressData []Progress
	for rows.Next() {
		var progress Progress
		err := rows.Scan(&progress.Date, &progress.Weight, &progress.BMI)
		if err != nil {
			http.Error(w, "Error scanning progress data: "+err.Error(), http.StatusInternalServerError)
			return
		}
		progressData = append(progressData, progress)
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(progressData)
}

// Helper function to get user ID from session
func getUserID(r *http.Request) (int, error) {
	session, _ := store.Get(r, "session")
	if userID, ok := session.Values["user_id"].(int); ok {
		return userID, nil
	}
	return 0, fmt.Errorf("no user_id in session")
}

func GetUserDataHandler(w http.ResponseWriter, r *http.Request) {
	session, _ := store.Get(r, "session")
	userID, ok := session.Values["user_id"].(int)
	if !ok {
		http.Error(w, "Unauthorized", http.StatusUnauthorized)
		return
	}

	db, err := sql.Open("mysql", "root:password@tcp(127.0.0.1:3306)/bmicalculator")
	if err != nil {
		http.Error(w, "Error connecting to database", http.StatusInternalServerError)
		return
	}
	defer db.Close()

	var user UserData
	query := "SELECT bmi, category, daily_calorie_needs, nama_lengkap FROM users WHERE id = ?"
	err = db.QueryRow(query, userID).Scan(&user.BMI, &user.Category, &user.DailyCalorieNeeds, &user.Nama)
	if err != nil {
		http.Error(w, "Error fetching user data: "+err.Error(), http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(user)
}

func GetProgressDataHandler(w http.ResponseWriter, r *http.Request) {
	userID, err := getUserID(r)
	if err != nil {
		http.Error(w, "Unauthorized: "+err.Error(), http.StatusUnauthorized)
		return
	}

	rows, err := db.Query(`SELECT date, weight, bmi FROM progress WHERE user_id = ?`, userID)
	if err != nil {
		log.Printf("Error fetching progress data: %v", err)
		http.Error(w, "Error fetching progress data: "+err.Error(), http.StatusInternalServerError)
		return
	}
	defer rows.Close()

	var progressData []Progress
	for rows.Next() {
		var progress Progress
		err := rows.Scan(&progress.Date, &progress.Weight, &progress.BMI)
		if err != nil {
			log.Printf("Error scanning progress data: %v", err)
			http.Error(w, "Error scanning progress data: "+err.Error(), http.StatusInternalServerError)
			return
		}
		progressData = append(progressData, progress)
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(progressData)
}

func authMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		session, _ := store.Get(r, "session")
		userID, ok := session.Values["user_id"].(int)
		if !ok || userID == 0 {
			http.Error(w, "Unauthorized", http.StatusUnauthorized)
			return
		}
		next.ServeHTTP(w, r)
	})
}
