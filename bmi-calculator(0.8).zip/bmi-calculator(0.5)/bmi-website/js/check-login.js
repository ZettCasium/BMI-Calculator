document.addEventListener('DOMContentLoaded', function() {
    // Check login status and update the navigation bar
    fetch('http://localhost:8081/check-login', {
        method: 'GET',
        credentials: 'include'
    })
    .then(response => {
        if (response.ok) {
            return response.text();
        } else {
            throw new Error('Not logged in');
        }
    })
    .then(email => {
        const authButtonDiv = document.getElementById('auth-button');
        if (authButtonDiv) {
            authButtonDiv.innerHTML = `<span class="text-gray-700">${email}</span> <button id="logout-btn" class="bg-[#56A4FF] text-white px-5 py-2 rounded-full hover:bg-[#87acec]">Logout</button>`;
            
            // Add logout functionality
            const logoutButton = document.getElementById('logout-btn');
            logoutButton.addEventListener('click', function() {
                fetch('http://localhost:8081/logout', {
                    method: 'POST',
                    credentials: 'include'
                })
                .then(response => {
                    if (response.ok) {
                        alert('Logged out successfully');
                        window.location.href = 'index.html';
                    } else {
                        throw new Error('Logout failed');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Logout failed');
                });
            });
        }
    })
    .catch(error => {
        console.log('User not logged in');
        // Keep the Sign in/Sign Up button
    });

    // Add event listener for the Sign in/Sign Up button if it exists
    const signinSignupButton = document.getElementById('signin-signup-btn');
    if (signinSignupButton) {
        signinSignupButton.addEventListener('click', function() {
            // Open a modal or redirect to login/signup page
            window.location.href = 'login.html'; // Change this to open a modal if needed
        });
    }
});
