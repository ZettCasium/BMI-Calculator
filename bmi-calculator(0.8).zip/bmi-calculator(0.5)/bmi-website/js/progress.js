document.getElementById('progress-form').addEventListener('submit', async function (e) {
    e.preventDefault();

    const formData = new FormData(this);
    const data = {
        date: formData.get('progress-date'),
        weight: formData.get('progress-weight'),
        bmi: formData.get('progress-bmi')
    };

    const response = await fetch('/submit-progress', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
    });

    const messageElement = document.getElementById('progressMessage');
    if (response.ok) {
        messageElement.innerText = "Progress data submitted successfully";
        messageElement.classList.remove('text-red-500');
        messageElement.classList.add('text-green-500');
    } else {
        const errorMessage = await response.text();
        messageElement.innerText = errorMessage;
        messageElement.classList.remove('text-green-500');
        messageElement.classList.add('text-red-500');
    }
});
