document.addEventListener('DOMContentLoaded', async function () {
    const authButton = document.getElementById('auth-button');
    const logoutButton = document.getElementById('logout-button');
    const usernameSpan = document.getElementById('username');
    const userDataButton = document.getElementById('user-data-button');

    async function checkLoginStatus() {
        try {
            const response = await fetch('/check-login');
            if (response.ok) {
                const data = await response.json();
                usernameSpan.textContent = data.username;
                authButton.style.display = 'none';
                logoutButton.style.display = 'inline-block';
                userDataButton.style.display = 'inline-block';
            } else {
                authButton.style.display = 'inline-block';
                logoutButton.style.display = 'none';
                userDataButton.style.display = 'none';
            }
        } catch (error) {
            console.error('Error checking login status:', error);
            authButton.style.display = 'inline-block';
            logoutButton.style.display = 'none';
            userDataButton.style.display = 'none';
        }
    }

    async function handleLogout() {
        try {
            const response = await fetch('/logout', { method: 'POST' });
            if (response.ok) {
                usernameSpan.textContent = '';
                authButton.style.display = 'inline-block';
                logoutButton.style.display = 'none';
                userDataButton.style.display = 'none';
                window.location.href = '/auth.html';
            } else {
                console.error('Logout failed');
            }
        } catch (error) {
            console.error('Error logging out:', error);
        }
    }

    authButton.addEventListener('click', function () {
        window.location.href = '/auth.html';
    });

    logoutButton.addEventListener('click', handleLogout);

    await checkLoginStatus();
});
