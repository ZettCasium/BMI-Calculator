document.addEventListener('DOMContentLoaded', async function () {
    const bmiElement = document.getElementById('bmi');
    const categoryElement = document.getElementById('category');
    const dailyCalorieNeedsElement = document.getElementById('daily-calorie-needs');
    const progressTableBody = document.getElementById('progressTableBody');

    async function fetchUserData() {
        try {
            const response = await fetch('/get-user-data');
            if (response.ok) {
                const data = await response.json();
                console.log('User Data:', data); // Log the data for debugging
                bmiElement.textContent = data.bmi;
                categoryElement.textContent = data.category;
                dailyCalorieNeedsElement.textContent = data.daily_calorie_needs;
            } else {
                console.error('Error fetching user data:', response.statusText);
            }
        } catch (error) {
            console.error('Error fetching user data:', error);
        }
    }

    async function fetchProgressData() {
        try {
            const response = await fetch('/get-progress-data');
            if (response.ok) {
                const data = await response.json();
                console.log('Progress Data:', data); // Log the data for debugging
                if (data.length > 0) {
                    progressTableBody.innerHTML = data.map(item => `
                        <tr>
                            <td class="border px-4 py-2">${item.date}</td>
                            <td class="border px-4 py-2">${item.weight}</td>
                            <td class="border px-4 py-2">${item.bmi}</td>
                        </tr>
                    `).join('');
                } else {
                    progressTableBody.innerHTML = '<tr><td colspan="3" class="border px-4 py-2">No progress data available.</td></tr>';
                }
            } else {
                console.error('Error fetching progress data:', response.statusText);
            }
        } catch (error) {
            console.error('Error fetching progress data:', error);
        }
    }

    await fetchUserData();
    await fetchProgressData();
});
