document.addEventListener('DOMContentLoaded', function() {
    // Load the modal HTML
    fetch('auth-modal.html')
        .then(response => response.text())
        .then(data => {
            document.body.insertAdjacentHTML('beforeend', data);
            initializeModal();
        });

    function initializeModal() {
        const button = document.getElementById('signin-signup-btn');
        const modal = document.getElementById('auth-modal');
        const closeModal = document.getElementById('close-modal');

        button.addEventListener('click', function() {
            modal.classList.remove('hidden');
        });

        closeModal.addEventListener('click', function() {
            modal.classList.add('hidden');
        });

        window.addEventListener('click', function(event) {
            if (event.target == modal) {
                modal.classList.add('hidden');
            }
        });
    }
});
