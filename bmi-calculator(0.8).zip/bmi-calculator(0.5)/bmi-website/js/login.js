document.getElementById('login-form').addEventListener('submit', async function (e) {
    e.preventDefault();

    const formData = new FormData(this);
    const data = {
        email: formData.get('login-email'),
        password: formData.get('login-password')
    };

    const response = await fetch('/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
    });

    const messageElement = document.getElementById('loginMessage');
    if (response.ok) {
        messageElement.innerText = "Login successful";
        messageElement.classList.remove('text-red-500');
        messageElement.classList.add('text-green-500');
        window.location.href = "/index.html"; // Redirect to the BMI calculator page on successful login
    } else {
        const errorMessage = await response.text();
        messageElement.innerText = errorMessage;
        messageElement.classList.remove('text-green-500');
        messageElement.classList.add('text-red-500');
    }
});
