document.querySelector('form').addEventListener('submit', async function(e) {
    e.preventDefault();

    const age = parseInt(document.getElementById('age').value);
    const weight = parseFloat(document.getElementById('weight').value);
    const height = parseFloat(document.getElementById('height').value);
    const activityLevel = parseFloat(document.querySelector('input[name="activityLevel"]:checked')?.value);

    console.log("Activity Level:", activityLevel);

    if (!activityLevel) {
        alert('Please select an activity level.');
        return;
    }

    try {
        const response = await fetch('http://localhost:8080/calculate-bmi', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ age, weight, height, activityLevel })
        });

        if (response.ok) {
            const result = await response.json();
            console.log(result); // Log respons JSON

            const bmiText = result.bmi ? `BMI: ${result.bmi.toFixed(2)}` : 'BMI: Error';
            const categoryText = result.category ? `Category: ${result.category}` : 'Category: Error';

            const bmr = 10 * parseFloat(weight) + 6.25 * parseFloat(height) - 5 * parseInt(age) + 5; // Untuk pria. Tambahkan -161 untuk wanita.

            // Check if result.activityLevel is correctly used
            const calories = bmr * parseFloat(result.activityLevel);

            const caloriesText = result.caloricNeeds ? `Daily Caloric Needs: ${result.caloricNeeds.toFixed(2)} kcal` : 'Daily Caloric Needs: Error';

            document.getElementById('result').innerText = `${bmiText}, ${categoryText}, ${caloriesText}`;
        } else {
            document.getElementById('result').innerText = 'Error calculating BMI';
        }
    } catch (error) {
        console.error('Error:', error);
        document.getElementById('result').innerText = 'Error calculating BMI';
    }
});
